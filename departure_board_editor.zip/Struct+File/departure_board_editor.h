//
// Created by niki on 5/13/26.
//

#ifndef STRUCT_FILE_DEPARTURE_BOARD_EDITOR_H
#define STRUCT_FILE_DEPARTURE_BOARD_EDITOR_H

#include "globals_and_structures.h"
#include "help_functions.h"
#include "input_output.h"
#include "one_sprite.h"
#include "many_sprites.h"
#include "display.h"

void start();

#endif //STRUCT_FILE_DEPARTURE_BOARD_EDITOR_H